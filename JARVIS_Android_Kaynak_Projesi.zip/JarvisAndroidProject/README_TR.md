# JARVIS Android — başlangıç projesi

Iron Man esintili, koyu/mavi hologram arayüzlü Kotlin + Jetpack Compose Android projesi.

## İçindekiler
- Türkçe konuşma tanıma (Android SpeechRecognizer)
- Türkçe sesli yanıt (Android TextToSpeech)
- Mikrofon iznini çalışma anında isteme
- Saat ve basit selamlama komutları
- JARVIS temalı ana ekran

## Önemli sınırlar
Bu ZIP **kaynak kod projesidir; derlenmiş APK değildir**. Bu çalışma ortamında Android SDK/Gradle ile derleme ve gerçek cihaz testi yapılmış değildir.
“Hey JARVIS” uyandırma kelimesi bu başlangıç sürümünde arka planda sürekli dinlemez. Ekrandaki düğmeye dokunarak dinlemeyi başlatır. Her zaman açık uyandırma için ayrıca wake-word motoru, foreground service, görünür bildirim, pil kısıtlamalarıyla ilgili kullanıcı ayarı ve Android sürümüne uygun izin akışı eklenmelidir.
Telefonun tüm özelliklerine sınırsız erişim Android tarafından verilmez. Her özellik için ayrı izin gerekir; bazı işlemler kullanıcı onayı veya sistem ekranı gerektirir.
Yapay zekâ API bağlantısı eklenmedi. Bir API anahtarı uygulamaya sabit gömülmemelidir; güvenli bir sunucu katmanı kullanılmalıdır.

## APK oluşturma
1. Projeyi Android Studio kurulu bir bilgisayarda aç.
2. Gradle senkronizasyonunu tamamla.
3. `Build > Build APK(s)` seç.
4. Test APK genellikle `app/build/outputs/apk/debug/app-debug.apk` konumuna çıkar.

Android Studio/SDK gereklidir. Yalnızca telefondan bu kaynak ZIP'i doğrudan APK'ya dönüştürmek genellikle mümkün değildir.
