package com.example.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

private val Bg = Color(0xFF050B14)
private val Panel = Color(0xFF0A1929)
private val Cyan = Color(0xFF22C8FF)
private val Blue = Color(0xFF087DFF)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var onResult: ((String) -> Unit)? = null

    private val audioPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) listen()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale("tr", "TR")
        }
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        }
        setContent {
            var status by remember { mutableStateOf("Hazırım. Mikrofon düğmesine dokun.") }
            var heard by remember { mutableStateOf("“Hey JARVIS”") }
            var reply by remember { mutableStateOf("Sizi dinliyorum. Size nasıl yardımcı olabilirim?") }

            onResult = { phrase ->
                heard = phrase
                val lower = phrase.lowercase(Locale("tr", "TR"))
                reply = when {
                    "hey jarvis" in lower -> "Buradayım. Komutunuzu söyleyin."
                    "saat" in lower -> "Saat: " + java.text.SimpleDateFormat("HH:mm", Locale("tr", "TR")).format(java.util.Date())
                    "merhaba" in lower || "selam" in lower -> "Merhaba. Size nasıl yardımcı olabilirim?"
                    "ayar" in lower -> "Telefon ayarlarını açmak için izinli sistem işlemleri eklenebilir."
                    else -> "Komutunuzu aldım. Bu başlangıç sürümünde yapay zekâ bağlantısı henüz yapılandırılmadı."
                }
                status = "Komut alındı"
                speak(reply)
            }

            MaterialTheme(colorScheme = darkColorScheme(
                primary = Cyan, background = Bg, surface = Panel,
                onBackground = Color.White, onSurface = Color.White
            )) {
                Column(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(Color(0xFF07182A), Bg, Color(0xFF02050A))
                    )).padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("J A R V I S", color = Cyan, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Text("SİSTEM ÇEVRİM İÇİ", color = Color(0xFF76DFFF), fontSize = 10.sp)
                    }
                    Spacer(Modifier.height(38.dp))
                    Box(
                        Modifier.size(220.dp).background(
                            Brush.radialGradient(listOf(Color(0xFF124D83), Color(0xFF07182A), Bg)),
                            CircleShape
                        ),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("◉", color = Cyan, fontSize = 82.sp)
                            Text("J.A.R.V.I.S.", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Light)
                            Text("SES ARAYÜZÜ", color = Cyan, fontSize = 10.sp)
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    Text(status, color = Cyan, fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(heard, color = Color.White, fontSize = 19.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                        Text(reply, Modifier.padding(16.dp), color = Color(0xFFD7EFFF), fontSize = 15.sp)
                    }
                    Spacer(Modifier.height(24.dp))
                    Button(
                        onClick = {
                            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO)
                                == PackageManager.PERMISSION_GRANTED) listen()
                            else audioPermission.launch(Manifest.permission.RECORD_AUDIO)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Blue),
                        modifier = Modifier.fillMaxWidth().height(58.dp),
                        shape = RoundedCornerShape(18.dp)
                    ) { Text("🎙  JARVIS'İ DİNLE", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.height(18.dp))
                    Text("HIZLI KOMUTLAR", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        QuickChip("Saat kaç?") { onResult?.invoke("Saat kaç?") }
                        QuickChip("Merhaba") { onResult?.invoke("Merhaba JARVIS") }
                    }
                    Spacer(Modifier.weight(1f))
                    Text("Mikrofon yalnızca başlattığında kullanılır • v1.0", color = Color.Gray, fontSize = 10.sp, textAlign = TextAlign.Center)
                }
            }
        }
    }

    private fun listen() {
        val recognizer = speechRecognizer ?: run {
            speak("Bu cihazda konuşma tanıma kullanılamıyor.")
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS sizi dinliyor")
        }
        recognizer.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { runOnUiThread { speak("Sesi anlayamadım. Tekrar deneyin.") } }
            override fun onResults(results: Bundle?) {
                val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (phrase != null) runOnUiThread { onResult?.invoke(phrase) }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer.startListening(intent)
    }

    private fun speak(message: String) {
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun QuickChip(label: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, border = androidx.compose.foundation.BorderStroke(1.dp, Cyan)) {
        Text(label, color = Color.White)
    }
}
